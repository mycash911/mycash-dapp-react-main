export default function App() {
  return null; // React just initializes AppKit
}
